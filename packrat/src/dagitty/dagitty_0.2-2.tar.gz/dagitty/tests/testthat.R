library(testthat)
library(dagitty)

test_check("dagitty")
