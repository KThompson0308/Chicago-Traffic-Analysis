.onAttach <- function(libname, pkgname) {
  packageStartupMessage("Welcome! Want to learn more? See two factoextra-related books at https://goo.gl/ve3WBa")
}